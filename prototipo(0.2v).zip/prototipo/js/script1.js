function handleClick() {
    // Obtiene elementos
    const pantallaPrincipal = document.getElementById('pantalla-principal');
    const botonJugar = document.getElementById('boton-jugar');
    const pantallaOpciones = document.getElementById('pantalla-opciones');
    const texto1 = document.querySelector('.texto1');
    
    // Verifica que los elementos existan
    if (!pantallaPrincipal || !pantallaOpciones) {
        console.error('No se encontraron los elementos necesarios');
        return;
    }
    
    // Aplicar borroso a la pantalla principal
    pantallaPrincipal.classList.add('blur');
    
    // Ocultar elementos de la pantalla principal
    pantallaPrincipal.style.transition = 'all 0.3s ease';
    pantallaPrincipal.style.opacity = '0.3'; // Reduce opacidad en lugar de ocultar completamente
    pantallaPrincipal.style.transform = 'translateY(-50px)';
    
    if (botonJugar) {
        botonJugar.style.transition = 'all 0.3s ease';
        botonJugar.style.opacity = '0';
        botonJugar.style.visibility = 'hidden';
    }
    
    if (texto1) {
        texto1.style.transition = 'all 0.3s ease';
        texto1.style.opacity = '0';
    }
    
    // Muestra pantalla de opciones
    setTimeout(() => {
        pantallaOpciones.classList.remove('oculta');
    }, 300);
}

function volverAtras() {
    const pantallaPrincipal = document.getElementById('pantalla-principal');
    const botonJugar = document.getElementById('boton-jugar');
    const pantallaOpciones = document.getElementById('pantalla-opciones');
    const texto1 = document.querySelector('.texto1');
    
    // Oculta pantalla de opciones
    pantallaOpciones.classList.add('oculta');
    
    // Devuelve pantalla principal
    setTimeout(() => {
        // Quitar el borroso
        pantallaPrincipal.classList.remove('blur');
        
        // Pequeño delay adicional para asegurar que el display se aplique
        setTimeout(() => {
            pantallaPrincipal.style.opacity = '1';
            pantallaPrincipal.style.transform = 'translateY(0)';
            
            if (botonJugar) {
                botonJugar.style.opacity = '1';
                botonJugar.style.visibility = 'visible';
            }
            
            if (texto1) {
                texto1.style.opacity = '1';
            }
        }, 50);
    }, 300);
}

function seleccionarOpcion(opcion) {
    if (opcion === 1) {
        // Redireccionar al modo auxiliar
        window.location.href = 'pantallas/modo auxiliar/auxiliar.html';
    } else if (opcion === 2) {
        // Redireccionar al modo jugable
        window.location.href = 'pantallas/modo jugable/jugable.html';
    }
}

// Efecto de parallax suave al hacer scroll (solo en pantalla principal)
window.addEventListener('scroll', () => {
    const pantallaPrincipal = document.getElementById('pantalla-principal');
    if (!pantallaPrincipal.classList.contains('blur')) {
        const scrolled = window.pageYOffset;
        const container = document.querySelector('.contenedor');
        if (container) {
            container.style.transform = `translateY(${scrolled * 0.1}px)`;
        }
    }
});